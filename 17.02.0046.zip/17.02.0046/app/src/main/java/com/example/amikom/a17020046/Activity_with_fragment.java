package com.example.amikom.a17020046;

import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity_with_fragment extends AppCompatActivity {

    //private Button fragment1;
   // private Button fragment2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_with_fragment);
    }

    public void fr1(View view) {
        android.support.v4.app.FragmentTransaction ft = getSupportFragmentManager().beginTransaction();

        ft.replace (R.id.framefragment, new BlankFragment1());

        ft.commit();
    }

    public void fr2(View view) {
        android.support.v4.app.FragmentTransaction ft = getSupportFragmentManager().beginTransaction();

        ft.replace (R.id.framefragment, new BlankFragment2());

        ft.commit();
    }

}